#include<stdio.h>
#include<stdlib.h>
void print(int b[],int t);
void per(int a[],int b[],int t,int size,int index);
int t;
int main()
{
  int *a,*b,size,tos,y,i;
  t=0;
  printf("enter the nmbers of chars \n");
  scanf("%d",&size);
  a=(int*)malloc(size*sizeof(int));
  b=(int*)malloc(size*sizeof(int));
  printf("enter %d chars now \n",size);
  for(i=0;i<size;i++)
    {
      scanf("%d",&a[i]);
    }
  printf("here is the possible power sets \n");
  per(a,b,t,size,0);
  scanf("%d",&y);
  return 0;
}
void per(int a[],int b[],int t,int size,int index)
{
  if(index==size) 
    {
      print(b,t);
      return ; 
    }
  per(a,b,t,size,index+1);
  b[t]=a[index];
  per(a,b,t+1,size,index+1);
  return ; 
}
void print(int b[],int t)
{
  int i;
  if(t==0)
    {
      printf("{no }\n");
      return ;
    }
  printf("{");
  for(i=0;i<t;i++)
    {
      printf("%d ",b[i]);
    }
  printf("}\n"); 
}
