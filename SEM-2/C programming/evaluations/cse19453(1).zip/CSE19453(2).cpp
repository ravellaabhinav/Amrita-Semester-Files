#include <stdio.h>
#include <stdlib.h>
int main( ) 
{
int i,num,a,b,c,d,e,f,n;
printf("The value of n is");
scanf("%d",&n);
a=0;
b=0;
c=0;
d=0;
e=0;
f=0;
for(i = 0;i<n;i++){
num = rand()%6;
if(num == 0){
a++;
}
if(num == 1){
b++;
}if(num == 2){
c++;
}
if(num == 3){
d++;
}
if(num == 4){
e++;
}
if(num == 5){
f++;
}
}
printf(" the frequency of a is %d\n",a);
printf(" the frequency of b is %d\n",b);
printf(" the frequency of c is %d\n",c);
printf(" the frequency of d is %d\n",d);
printf(" the frequency of e is %d\n",e);
printf(" the frequency of f is %d\n",f);
return 0;
}
